import './Components/index'
import UserForm from './Components/index'

const App=()=>(
    <div className="form">
        <UserForm/>
    </div>
)
export default App