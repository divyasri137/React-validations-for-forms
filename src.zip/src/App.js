import {useState} from "react";
import './Components/index'
import './App.css';

function App() {
 const[firstNameInput,setFirstNameInput]=useState("")
 const[lastNameInput,setLastNameInput]=useState("")
 const[mobileInput,setMobileInput]=useState("")
 const[emailInput,setEmailInput]=useState("")
 const[dobInput,setdobInput]=useState("")

function onChangeFirstName(e){
  setFirstNameInput(e.target.value)
  if (e.target.value===""){
    setLastNameInput(true)
  }
  else{
    setFirstNameInput(false)
  }
}

 function onChangeLastName(e){
    setLastNameInput(e.target.value)
    if (e.target.value===""){
      setLastNameInput(true)
    }
    else{
      setLastNameInput(false)
    }
 }

 function onChangeMobile(e){
  setMobileInput(e.target.value)
  if (parseInt(e.target.value.length>10)){
    setEmailInput(false)
  }
  else{
    setEmailInput(false)
  }
 }

 function onChangeEmail(e){
  setEmailInput(e.target.value)
  if (e.target.value===""){
    setEmailInput(true)
  }
  else{
    setEmailInput(false)
  }
 }

 function onChangeDob(e){
  setdobInput(e.target.value)
  if (e.target.value===""){
    setdobInput(true)
  }
  else{
    setdobInput(false)
  }
 }

  return (
    <div className="container">
    <div className="user-container">
      <h1 className="heading">Employee</h1>
    <div className="row1">
        <input onChange={onChangeFirstName} type="text" className="first-name" placeholder="First-Name" />
        {firstNameInput? <p>Required*</p>:null}
        <input onChange={onChangeLastName} type="text" placeholder="Last-Name"/>
        {lastNameInput? <p>Required*</p>:null}
    </div>
    <div>
        <input type="number" onChange={onChangeMobile} placeholder="Mobile"/>
        {mobileInput?<p></p>:null}
        <input type="email" onChange={onChangeEmail} placeholder="Email"/>
        {emailInput? <p>Required*</p>:null}
    </div>
    <div>
        <input onChange={onChangeDob} type="date" placeholder="DOB"/>
        {dobInput?<p>Please Enter a valid date</p>:null}
        <input type="date" placeholder="DOJ"/>
    </div>
    <div>
      <button className="btn">Add</button>
    </div>
    {/* <table border={1}>
      <tr>
        <th>Nature of Institution</th>
        <td>By Shift</td>
        <td>Empty</td>
      </tr>
      <tr>
        <th>Type of Institution</th>
        <tr>
          <td>By Gender</td>
          <td>Empty</td>
        </tr>
        
        <tr>
          <td>By Shift</td>
          <td>Empty</td>
        </tr>
      </tr>
    </table> */}
   </div>
   </div>
  );
}

export default App;


//  function onChangingFirstName(e){
//     console.log(Number.isNaN(parseInt(e.target.value,10)))
//     // setFirstNameInput(e.target.value)
//     // if (Number.isInteger(parseInt(firstNameInput,10))){
//     //   setFirstNameStatus(false)
//     //   console.log(e.target.value)
//     //   console.log(firstNameInput)
//     // }else{
//     //   setFirstNameStatus(true)
//     //   console.log(e.target.value)
//     //   console.log(firstNameInput)}
//   }